# The Order of the Inertia Bound for Random Graphs

**Authors:** Zhengbo Chen and Xiao-Dong Zhang  
**Manuscript date:** 21 October 2026

- [Read the paper (PDF)](paper.pdf)
- [LaTeX source](paper.tex)

The LaTeX source is preserved exactly as supplied by the authors.

## Build

With a TeX distribution and `latexmk` installed, run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
```
